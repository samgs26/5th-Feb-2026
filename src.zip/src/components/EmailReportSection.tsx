import { useState, useRef } from 'react';
import { ChevronDown, ChevronUp, Mail, Send, CheckCircle, Plus, X, Paperclip, FileText } from 'lucide-react';
import { sendEmail } from '../services/api';

interface EmailReportSectionProps {
  category: string;
  variant?: 'admin' | 'user';
}

export function EmailReportSection({ category, variant = 'user' }: EmailReportSectionProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [recipients, setRecipients] = useState<string[]>([]);
  const [currentEmail, setCurrentEmail] = useState('');
  const [subject, setSubject] = useState(`${category} Report`);
  const [message, setMessage] = useState('');
  const [sendStatus, setSendStatus] = useState<'idle' | 'sending' | 'success'>('idle');
  const [attachedFiles, setAttachedFiles] = useState<File[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const addRecipient = () => {
    if (currentEmail && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(currentEmail)) {
      if (!recipients.includes(currentEmail)) {
        setRecipients([...recipients, currentEmail]);
        setCurrentEmail('');
      }
    }
  };

  const removeRecipient = (email: string) => {
    setRecipients(recipients.filter(r => r !== email));
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setAttachedFiles([...attachedFiles, ...Array.from(e.target.files)]);
    }
  };

  const removeAttachment = (index: number) => {
    setAttachedFiles(attachedFiles.filter((_, i) => i !== index));
  };

  const handleSend = async () => {
    let finalRecipients = [...recipients];

    // Auto-add current email if it's valid but not yet in the list
    if (currentEmail && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(currentEmail)) {
      if (!finalRecipients.includes(currentEmail)) {
        finalRecipients.push(currentEmail);
      }
    }

    if (finalRecipients.length === 0) {
      alert('Please add at least one recipient');
      return;
    }

    setSendStatus('sending');
    try {
      await sendEmail(finalRecipients, subject, message || `Please find the attached ${category} report.`, attachedFiles);
      setSendStatus('success');
      setTimeout(() => {
        setSendStatus('idle');
        setRecipients([]);
        setCurrentEmail('');
        setMessage('');
        setAttachedFiles([]);
      }, 2000);
    } catch (error) {
      console.error('Failed to send email:', error);
      alert('Failed to send email. Please check your SMTP settings in the backend .env file.');
      setSendStatus('idle');
    }
  };

  const isAdmin = variant === 'admin';
  const primaryColor = isAdmin ? 'purple' : 'teal';
  const secondaryColor = isAdmin ? 'indigo' : 'blue';

  return (
    <div className={`border-2 ${isAdmin ? 'border-purple-200' : 'border-teal-200'} rounded-xl overflow-hidden bg-white shadow-md`}>
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className={`w-full flex items-center justify-between px-5 py-4 bg-gradient-to-r ${isAdmin ? 'from-purple-50 to-indigo-50 hover:from-purple-100 hover:to-indigo-100' : 'from-teal-50 to-blue-50 hover:from-teal-100 hover:to-blue-100'
          } transition-all`}
      >
        <div className="flex items-center gap-3">
          <div className={`p-2 ${isAdmin ? 'bg-purple-600' : 'bg-teal-600'} rounded-lg`}>
            <Mail className="size-5 text-white" />
          </div>
          <div className="text-left">
            <h3 className={`font-bold ${isAdmin ? 'text-purple-700' : 'text-teal-700'}`}>Email Report</h3>
            <p className={`text-xs ${isAdmin ? 'text-purple-600' : 'text-teal-600'}`}>Share {category} report via email</p>
          </div>
        </div>
        {isExpanded ? (
          <ChevronUp className={`size-5 ${isAdmin ? 'text-purple-600' : 'text-teal-600'}`} />
        ) : (
          <ChevronDown className={`size-5 ${isAdmin ? 'text-purple-600' : 'text-teal-600'}`} />
        )}
      </button>

      {isExpanded && (
        <div className={`p-5 border-t-2 ${isAdmin ? 'border-purple-100' : 'border-teal-100'}`}>
          {/* Email Recipients */}
          <div className="mb-4">
            <label className="block text-sm font-semibold text-gray-700 mb-2">Recipients</label>
            <div className="flex gap-2">
              <input
                type="email"
                value={currentEmail}
                onChange={(e) => setCurrentEmail(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    addRecipient();
                  }
                }}
                placeholder="Enter email address"
                className={`flex-1 px-4 py-2 border-2 ${isAdmin ? 'border-purple-200 focus:border-purple-500 focus:ring-purple-500' : 'border-teal-200 focus:border-teal-500 focus:ring-teal-500'
                  } rounded-lg focus:outline-none focus:ring-2 transition-all`}
              />
              <button
                onClick={addRecipient}
                className={`flex items-center gap-2 px-4 py-2 bg-gradient-to-r ${isAdmin ? 'from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700' : 'from-teal-600 to-blue-600 hover:from-teal-700 hover:to-blue-700'
                  } text-white rounded-lg transition-all font-medium`}
              >
                <Plus className="size-5" />
                Add
              </button>
            </div>

            {/* Recipients List */}
            {recipients.length > 0 ? (
              <div className="mt-3 flex flex-wrap gap-2">
                {recipients.map((email) => (
                  <div
                    key={email}
                    className={`flex items-center gap-2 px-3 py-1.5 bg-gradient-to-r ${isAdmin ? 'from-purple-100 to-indigo-100 border-purple-300' : 'from-teal-100 to-blue-100 border-teal-300'
                      } border rounded-full`}
                  >
                    <span className="text-sm font-medium text-gray-700">{email}</span>
                    <button
                      onClick={() => removeRecipient(email)}
                      className="p-0.5 hover:bg-red-100 rounded-full transition-colors"
                    >
                      <X className="size-3.5 text-red-500" />
                    </button>
                  </div>
                ))}
              </div>
            ) : (
              <p className="mt-2 text-xs text-amber-600 italic">
                ⚠️ Please add at least one recipient email and click "Add" to enable sending.
              </p>
            )}
          </div>

          {/* Subject */}
          <div className="mb-4">
            <label className="block text-sm font-semibold text-gray-700 mb-2">Subject</label>
            <input
              type="text"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              className={`w-full px-4 py-2 border-2 ${isAdmin ? 'border-purple-200 focus:border-purple-500 focus:ring-purple-500' : 'border-teal-200 focus:border-teal-500 focus:ring-teal-500'
                } rounded-lg focus:outline-none focus:ring-2 transition-all`}
            />
          </div>

          {/* Message Area with Attachment Support */}
          <div className="mb-4">
            <div className="flex justify-between items-center mb-2">
              <label className="block text-sm font-semibold text-gray-700">Message (Optional)</label>
              <div className="flex items-center gap-2">
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileSelect}
                  className="hidden"
                  multiple
                />
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border-2 transition-all ${isAdmin
                      ? 'text-purple-600 border-purple-200 hover:bg-purple-50 hover:border-purple-300'
                      : 'text-teal-600 border-teal-200 hover:bg-teal-50 hover:border-teal-300'
                    }`}
                  title="Attach files"
                >
                  <Paperclip className="size-3.5" />
                  Attach Files
                </button>
              </div>
            </div>
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              rows={4}
              placeholder="Add a message to include with the report..."
              className={`w-full px-4 py-2 border-2 ${isAdmin ? 'border-purple-200 focus:border-purple-500 focus:ring-purple-500' : 'border-teal-200 focus:border-teal-500 focus:ring-teal-500'
                } rounded-lg focus:outline-none focus:ring-2 transition-all resize-none mb-3`}
            />

            {/* Attached Files List */}
            {attachedFiles.length > 0 && (
              <div className="flex flex-wrap gap-2 animate-in fade-in slide-in-from-top-2">
                {attachedFiles.map((file, index) => (
                  <div
                    key={index}
                    className={`flex items-center gap-2 px-3 py-1.5 bg-gray-50 border-2 rounded-lg text-xs group ${isAdmin ? 'border-purple-100' : 'border-teal-100'
                      }`}
                  >
                    <FileText className={`size-3.5 ${isAdmin ? 'text-purple-500' : 'text-teal-500'}`} />
                    <span className="max-w-[150px] truncate font-medium text-gray-700">{file.name}</span>
                    <span className="text-gray-400">({(file.size / 1024).toFixed(1)} KB)</span>
                    <button
                      onClick={() => removeAttachment(index)}
                      className="p-1 hover:bg-red-100 rounded-lg transition-colors"
                      title="Remove file"
                    >
                      <X className="size-3 text-red-500" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Report Options */}
          <div className={`mb-4 p-4 bg-gradient-to-r ${isAdmin ? 'from-purple-50 to-indigo-50 border-purple-200' : 'from-teal-50 to-blue-50 border-teal-200'
            } border rounded-lg`}>
            <p className="text-sm font-semibold text-gray-700 mb-2">Report Format</p>
            <div className="flex gap-3">
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" defaultChecked className={`${isAdmin ? 'accent-purple-600' : 'accent-teal-600'}`} />
                <span className="text-sm text-gray-700">PDF</span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" className={`${isAdmin ? 'accent-purple-600' : 'accent-teal-600'}`} />
                <span className="text-sm text-gray-700">Excel</span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" className={`${isAdmin ? 'accent-purple-600' : 'accent-teal-600'}`} />
                <span className="text-sm text-gray-700">CSV</span>
              </label>
            </div>
          </div>

          {/* Send Button */}
          <div className="space-y-2">
            <button
              onClick={handleSend}
              disabled={sendStatus !== 'idle' || (recipients.length === 0 && !(/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(currentEmail)))}
              title={recipients.length === 0 && !(/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(currentEmail)) ? "Please add recipients first" : "Send this report"}
              className={`w-full flex items-center justify-center gap-2 px-4 py-3 bg-gradient-to-r ${isAdmin ? 'from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700' : 'from-teal-600 to-blue-600 hover:from-teal-700 hover:to-blue-700'
                } text-white rounded-lg transition-all font-semibold shadow-lg disabled:opacity-50 disabled:cursor-not-allowed disabled:from-gray-400 disabled:to-gray-500`}
            >
              {sendStatus === 'sending' && (
                <>
                  <div className="size-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  Sending...
                </>
              )}
              {sendStatus === 'success' && (
                <>
                  <CheckCircle className="size-5" />
                  Sent Successfully!
                </>
              )}
              {sendStatus === 'idle' && (
                <>
                  <Send className="size-5" />
                  Send Report
                </>
              )}
            </button>

            {sendStatus === 'success' && (
              <p className="text-center text-sm text-green-600 font-medium animate-bounce mt-2">
                ✅ The backend has confirmed the email was handed over to the SMTP server.
              </p>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
