import { useState, useRef } from 'react';
import { LogOut, BarChart3, MessageSquare, Send, X, File, Paperclip } from 'lucide-react';
import { AdminDataManager } from './AdminDataManager';
import { PolicyDetailView } from './PolicyDetailView';
import { chatWithAI, uploadDocument } from '../services/api';

interface AdminDashboardProps {
  onLogout: () => void;
}

type ReportType = 'onboarding' | 'offboarding' | 'invoice' | 'variance' | 'policy' | 'newOnboardingDocs';

const reportTypes: { id: ReportType; label: string }[] = [
  { id: 'onboarding', label: 'Onboarding' },
  { id: 'offboarding', label: 'Offboarding' },
  { id: 'invoice', label: 'Invoice' },
  { id: 'variance', label: 'Variance' },
  { id: 'policy', label: 'Policy' },
  { id: 'newOnboardingDocs', label: 'New Onboarding Documents' },
];

export function AdminDashboard({ onLogout }: AdminDashboardProps) {
  const [selectedReport, setSelectedReport] = useState<ReportType>('onboarding');
  const [chatMessages, setChatMessages] = useState<{ id: number; text: string; sender: 'user' | 'bot'; timestamp: Date }[]>([
    { id: 1, text: "Admin Assistant ready. How can I help with reports or policies today?", sender: 'bot', timestamp: new Date() }
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [attachedFiles, setAttachedFiles] = useState<File[]>([]);
  const [isAIExpanded, setIsAIExpanded] = useState(false);
  const [refreshTrigger, setRefreshTrigger] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleRefresh = () => {
    setRefreshTrigger(prev => prev + 1);
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const newFiles = Array.from(e.target.files);
      setAttachedFiles([...attachedFiles, ...newFiles]);
    }
  };

  const removeAttachment = (index: number) => {
    setAttachedFiles(attachedFiles.filter((_, i) => i !== index));
  };

  const handleSendMessage = async () => {
    if (!inputMessage.trim() && attachedFiles.length === 0) return;

    const userMessageText = inputMessage || (attachedFiles.length > 0 ? `📎 Sent ${attachedFiles.length} attachment(s)` : '');

    const newMessage = {
      id: Date.now(),
      text: userMessageText,
      sender: 'user' as const,
      timestamp: new Date(),
    };

    setChatMessages(prev => [...prev, newMessage]);
    const currentInput = inputMessage;
    const currentFiles = [...attachedFiles];
    setInputMessage('');
    setAttachedFiles([]);

    // Upload files if any
    if (currentFiles.length > 0) {
      for (const file of currentFiles) {
        try {
          await uploadDocument(file, selectedReport);
        } catch (error) {
          console.error(`Error uploading ${file.name}:`, error);
        }
      }
      handleRefresh();
    }

    try {
      // Pass the selected report as the category to use the specialized agent
      const response = await chatWithAI(currentInput || userMessageText, 'admin', selectedReport);
      const botResponse = {
        id: Date.now() + 1,
        text: response,
        sender: 'bot' as const,
        timestamp: new Date(),
      };
      setChatMessages(prev => [...prev, botResponse]);

      // If AI response suggests a record was added/updated, trigger refresh
      if (response.toLowerCase().includes('added') || response.toLowerCase().includes('updated') || response.toLowerCase().includes('deleted')) {
        handleRefresh();
      }
    } catch (error: any) {
      const errorMsg = error.response?.data?.detail || "Error connecting to AI service. Please ensure the backend is running.";
      setChatMessages(prev => [...prev, {
        id: Date.now() + 1,
        text: typeof errorMsg === 'string' ? errorMsg : JSON.stringify(errorMsg),
        sender: 'bot' as const,
        timestamp: new Date(),
      }]);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-indigo-50 to-purple-100 flex flex-col">
      {/* Header */}
      <header className="bg-gradient-to-r from-purple-600 to-indigo-600 shadow-lg px-6 py-4 relative z-10">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white/20 rounded-lg">
              <BarChart3 className="size-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl text-white font-bold">Admin Dashboard</h1>
              <p className="text-purple-100 text-sm">Manage and monitor all reports</p>
            </div>
          </div>
          <button
            onClick={onLogout}
            className="flex items-center gap-2 px-4 py-2 bg-white/10 text-white hover:bg-white/20 rounded-lg transition-all backdrop-blur-sm border border-white/20"
          >
            <LogOut className="size-5" />
            Logout
          </button>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden">
        {/* Side Navigation */}
        <aside className="w-72 bg-white shadow-lg overflow-y-auto">
          <div className="p-6">
            <div className="mb-6">
              <div className="flex items-center gap-2 text-purple-600 mb-2">
                <div className="size-2 bg-purple-600 rounded-full"></div>
                <p className="text-xs font-bold uppercase tracking-wider">Report Categories</p>
              </div>
              <div className="h-1 w-12 bg-gradient-to-r from-purple-600 to-indigo-600 rounded-full"></div>
            </div>
            <nav className="space-y-2">
              {reportTypes.map((report) => (
                <button
                  key={report.id}
                  onClick={() => setSelectedReport(report.id)}
                  className={`w-full text-left px-4 py-3 rounded-xl transition-all font-medium ${selectedReport === report.id
                    ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-lg shadow-purple-500/50 transform scale-105'
                    : 'text-gray-700 hover:bg-purple-50 hover:text-purple-700'
                    }`}
                >
                  {report.label}
                </button>
              ))}
            </nav>
          </div>
        </aside>

        {/* Main Content Area */}
        <main className="flex-1 p-8 overflow-y-auto relative">
          <div className="bg-white rounded-2xl shadow-xl border border-purple-100 min-h-full">
            <div className="px-8 py-6 border-b border-gray-200 bg-gradient-to-r from-purple-50 to-indigo-50">
              <h2 className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-indigo-600 bg-clip-text text-transparent">
                {reportTypes.find(r => r.id === selectedReport)?.label} Report
              </h2>
              <p className="text-gray-600 text-sm mt-1">View, edit, and manage records</p>
            </div>
            <div className="p-8">
              {selectedReport === 'policy' ? (
                <PolicyDetailView
                  policyType="HR Policies"
                  variant="admin"
                />
              ) : (
                <AdminDataManager reportType={selectedReport} refreshTrigger={refreshTrigger} />
              )}
            </div>
          </div>

          {/* AI Assistant Floating Panel */}
          <div className={`fixed bottom-8 right-8 transition-all duration-300 z-50 ${isAIExpanded ? 'w-96' : 'w-16'}`}>
            {isAIExpanded ? (
              <div className="bg-white rounded-2xl shadow-2xl border-2 border-purple-100 flex flex-col h-[500px]">
                <div className="p-4 bg-gradient-to-r from-purple-600 to-indigo-600 text-white rounded-t-xl flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <MessageSquare className="size-5" />
                    <span className="font-bold">Admin AI Assistant</span>
                  </div>
                  <button onClick={() => setIsAIExpanded(false)} className="hover:bg-white/20 p-1 rounded">
                    <X className="size-5" />
                  </button>
                </div>

                <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-purple-50/30">
                  {chatMessages.map(msg => (
                    <div key={msg.id} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                      <div className={`max-w-[85%] p-3 rounded-2xl text-sm shadow-sm ${msg.sender === 'user' ? 'bg-purple-600 text-white' : 'bg-white text-gray-800 border border-purple-100'
                        }`}>
                        {msg.text}
                      </div>
                    </div>
                  ))}
                </div>

                <div className="p-3 border-t bg-white rounded-b-xl space-y-3">
                  {attachedFiles.length > 0 && (
                    <div className="flex flex-wrap gap-2 px-1">
                      {attachedFiles.map((file, index) => (
                        <div key={index} className="flex items-center gap-1.5 bg-purple-50 text-purple-700 px-2 py-1 rounded-md text-xs border border-purple-100 group">
                          <File className="size-3" />
                          <span className="truncate max-w-[100px]">{file.name}</span>
                          <button onClick={() => removeAttachment(index)} className="hover:text-red-500">
                            <X className="size-3" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                  <div className="flex gap-2">
                    <input
                      type="file"
                      ref={fileInputRef}
                      onChange={handleFileSelect}
                      multiple
                      className="hidden"
                    />
                    <button
                      onClick={() => fileInputRef.current?.click()}
                      className="p-2 hover:bg-purple-50 rounded-lg text-purple-600 transition-colors"
                      title="Attach documents"
                    >
                      <Paperclip className="size-5" />
                    </button>
                    <input
                      type="text"
                      value={inputMessage}
                      onChange={(e) => setInputMessage(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                      placeholder="Ask about reports or policies..."
                      className="flex-1 border rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-purple-500"
                    />
                    <button
                      onClick={handleSendMessage}
                      disabled={!inputMessage.trim() && attachedFiles.length === 0}
                      className="bg-purple-600 text-white p-2 rounded-lg hover:bg-purple-700 disabled:opacity-50"
                    >
                      <Send className="size-5" />
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <button
                onClick={() => setIsAIExpanded(true)}
                className="size-16 bg-gradient-to-r from-purple-600 to-indigo-600 text-white rounded-full shadow-lg hover:shadow-xl transform hover:scale-110 transition-all flex items-center justify-center"
              >
                <MessageSquare className="size-8" />
              </button>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}