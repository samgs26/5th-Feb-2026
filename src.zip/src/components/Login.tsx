import { useState, FormEvent } from 'react';
import { UserType, LoginProps } from '../types';
import { Shield, User } from 'lucide-react';

export function Login({ onLogin }: LoginProps) {
  const [selectedType, setSelectedType] = useState<UserType>(null);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e: FormEvent) => {

    e.preventDefault();
    if (username.trim() && password.trim() && selectedType) {
      onLogin(selectedType);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-100 via-purple-50 to-teal-100 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-8 border border-gray-100">
        <div className="text-center mb-8">
          <h1 className="text-3xl mb-2 bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">Welcome Back</h1>
          <p className="text-gray-500 text-sm">Please select your user type and sign in</p>
        </div>

        <div className="mb-6">
          <p className="text-sm text-gray-600 mb-4 font-medium">Select User Type:</p>
          <div className="grid grid-cols-2 gap-4">
            <button
              type="button"
              onClick={() => setSelectedType('admin')}
              className={`flex flex-col items-center justify-center p-6 rounded-xl border-2 transition-all transform hover:scale-105 ${selectedType === 'admin'
                ? 'border-purple-500 bg-gradient-to-br from-purple-50 to-indigo-50 shadow-lg'
                : 'border-gray-200 hover:border-purple-300 hover:shadow-md'
                }`}
            >
              <div className={`p-3 rounded-full mb-3 ${selectedType === 'admin' ? 'bg-purple-100' : 'bg-gray-100'}`}>
                <Shield className={`size-8 ${selectedType === 'admin' ? 'text-purple-600' : 'text-gray-400'}`} />
              </div>
              <span className={`font-semibold ${selectedType === 'admin' ? 'text-purple-700' : 'text-gray-600'}`}>Admin</span>
              <span className="text-xs text-gray-500 mt-1">Full Access</span>
            </button>

            <button
              type="button"
              onClick={() => setSelectedType('general')}
              className={`flex flex-col items-center justify-center p-6 rounded-xl border-2 transition-all transform hover:scale-105 ${selectedType === 'general'
                ? 'border-teal-500 bg-gradient-to-br from-teal-50 to-blue-50 shadow-lg'
                : 'border-gray-200 hover:border-teal-300 hover:shadow-md'
                }`}
            >
              <div className={`p-3 rounded-full mb-3 ${selectedType === 'general' ? 'bg-teal-100' : 'bg-gray-100'}`}>
                <User className={`size-8 ${selectedType === 'general' ? 'text-teal-600' : 'text-gray-400'}`} />
              </div>
              <span className={`font-semibold ${selectedType === 'general' ? 'text-teal-700' : 'text-gray-600'}`}>General User</span>
              <span className="text-xs text-gray-500 mt-1">Standard Access</span>
            </button>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label htmlFor="username" className="block text-sm text-gray-700 mb-2 font-medium">
              Username
            </label>
            <input
              type="text"
              id="username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
              placeholder="Enter your username"
              required
            />
          </div>

          <div>
            <label htmlFor="password" className="block text-sm text-gray-700 mb-2 font-medium">
              Password
            </label>
            <input
              type="password"
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
              placeholder="Enter your password"
              required
            />
          </div>

          <button
            type="submit"
            disabled={!selectedType}
            className={`w-full py-3 px-4 rounded-lg font-semibold transition-all transform hover:scale-105 disabled:transform-none disabled:cursor-not-allowed mt-6 ${selectedType === 'admin'
              ? 'bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white shadow-lg hover:shadow-xl disabled:from-gray-300 disabled:to-gray-300'
              : selectedType === 'general'
                ? 'bg-gradient-to-r from-teal-600 to-blue-600 hover:from-teal-700 hover:to-blue-700 text-white shadow-lg hover:shadow-xl disabled:from-gray-300 disabled:to-gray-300'
                : 'bg-gray-300 text-gray-500'
              }`}
          >
            Sign In
          </button>
        </form>
      </div>
    </div>
  );
}