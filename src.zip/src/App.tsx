import { useState } from 'react';
import { UserType } from './types';
import { Login } from './components/Login';
import { AdminDashboard } from './components/AdminDashboard';
import { GeneralUserDashboard } from './components/GeneralUserDashboard';


export default function App() {
  const [userType, setUserType] = useState<UserType>(null);

  const handleLogout = () => {
    setUserType(null);
  };

  if (!userType) {
    return <Login onLogin={setUserType} />;
  }

  if (userType === 'admin') {
    return <AdminDashboard onLogout={handleLogout} />;
  }

  return <GeneralUserDashboard onLogout={handleLogout} />;
}
