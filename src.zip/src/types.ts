export type UserType = 'admin' | 'general' | null;

export interface LoginProps {
    onLogin: (userType: UserType) => void;
}
