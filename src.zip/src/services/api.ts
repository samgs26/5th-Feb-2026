import axios from 'axios';

const API_BASE_URL = 'http://localhost:8000';

const api = axios.create({
    baseURL: API_BASE_URL,
});

export const chatWithAI = async (message: string, role: 'admin' | 'user', category?: string) => {
    const response = await api.post('/chat', {
        message,
        role,
        category,
    });
    return response.data.response;
};

export const getRecords = async (category: string) => {
    const response = await api.get(`/records/${category}`);
    return response.data;
};

export const getRecordStats = async (category: string) => {
    const response = await api.get(`/records/stats/${category}`);
    return response.data;
};

export const addRecord = async (category: string, record: any) => {
    const response = await api.post(`/records/${category}`, record);
    return response.data;
};

export const deleteRecord = async (category: string, field: string, value: string) => {
    const response = await api.delete(`/records/${category}/${field}/${value}`);
    return response.data;
};

export const sendEmail = async (recipients: string[], subject: string, message: string, attachments?: File[]) => {
    const formData = new FormData();
    formData.append('recipients', recipients.join(','));
    formData.append('subject', subject);
    formData.append('message', message);

    if (attachments && attachments.length > 0) {
        attachments.forEach((file) => {
            formData.append('files', file);
        });
    }

    const response = await api.post('/send-email', formData, {
        headers: {
            'Content-Type': 'multipart/form-data',
        },
    });
    return response.data;
};

export const uploadDocument = async (file: File, category?: string) => {
    const formData = new FormData();
    formData.append('file', file);
    if (category) {
        formData.append('category', category);
    }
    const response = await api.post('/upload', formData, {
        headers: {
            'Content-Type': 'multipart/form-data',
        },
    });
    return response.data;
};

export default api;
